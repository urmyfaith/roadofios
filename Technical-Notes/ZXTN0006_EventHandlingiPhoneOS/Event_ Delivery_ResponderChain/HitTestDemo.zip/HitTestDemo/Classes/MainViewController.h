//
//  MainViewController.h
//  HitTestDemo
//
//  Created by Tyler Neylon on 6/15/10.
//  Copyleft Bynomial 2010.
//

#import <UIKit/UIKit.h>


@interface MainViewController : UIViewController {
 @private
  // weak
  UITextView *textView;
}

@end
