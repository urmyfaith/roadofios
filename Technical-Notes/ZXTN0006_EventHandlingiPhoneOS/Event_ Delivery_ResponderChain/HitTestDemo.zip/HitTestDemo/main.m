//
//  main.m
//  HitTestDemo
//
//  Created by Tyler Neylon on 6/15/10.
//  Copyleft Bynomial 2010.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
