//
//  ZXDateCell.m
//  0103_QQ
//
//  Created by zx on 1/3/15.
//  Copyright (c) 2015 zx. All rights reserved.
//

#import "ZXDateCell.h"
#import "ZXMessageModel.h"

@implementation ZXDateCell

+(ZXDateCell *)cellWithTableView:(UITableView *)tableView{
    static NSString *indentifier = @"dataCell";
    ZXDateCell *cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    if (cell == nil) {
        cell = [[ZXDateCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        UIView *labelBackGround = [[UIView alloc] initWithFrame:CGRectMake(0, 10, 50, 20)];
        labelBackGround.center = CGPointMake(320/2, 44/2);
        
        [labelBackGround.layer setMasksToBounds:YES];
        [labelBackGround.layer setCornerRadius:10];//radius of circle
        [labelBackGround.layer setBorderWidth:0];
        
        labelBackGround.backgroundColor = [UIColor colorWithRed:200/255. green:200/255. blue:200/255 alpha:0.5];
        [self.contentView addSubview:labelBackGround];
        
        UILabel *label4Date = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 50, 40)];
        label4Date.center = CGPointMake(320/2, 44/2);
        label4Date.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:label4Date];
        self.dateLabel = label4Date;
    }
    return  self;
}

-(void)setMessageModel:(ZXMessageModel *)messageModel{
    _messageModel = messageModel;
    self.dateLabel.text = messageModel.messageContent;
}



@end
