//
//  ViewController.m
//  0103_QQ
//
//  Created by zx on 1/3/15.
//  Copyright (c) 2015 zx. All rights reserved.
//

#import "ViewController.h"
#import "ZXDatabase.h"
#import "ZXMessageModel.h"

@interface ViewController ()
@property (nonatomic,strong) ZXDatabase     *qqDB;
@property (nonatomic,strong) NSMutableArray         *meassages_Marray;
@property (nonatomic,strong) NSMutableArray         *users_Marray;
@end

@implementation ViewController

-(NSMutableArray *)meassages_Marray{
    if (_meassages_Marray == nil) {
        _meassages_Marray = [NSMutableArray array];
    }
    return _meassages_Marray;
}

-(NSMutableArray *)users_Marray{
    if (_users_Marray == nil) {
        _users_Marray = [NSMutableArray array];
    }
    return _users_Marray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    ZXDatabase *db = [[ZXDatabase alloc]init];
    NSLog(@"%s [LINE:%d] db=%@", __func__, __LINE__,db);//断点执行,检查数据库是对象的数据库路径是否为空
    [self loadTableData];
}



-(void)loadTableData{
    self.qqDB = [ZXDatabase shardInstance];
    
    NSString *messageSqlString = @"select * from messageInfoTable";
    FMResultSet *messages_results = [self.qqDB.database executeQuery:messageSqlString];
    while (messages_results.next) {
        ZXMessageModel *messageModel = [ZXMessageModel modelWithOneRowResult:messages_results];
        [self.meassages_Marray addObject:messageModel];
    }
    
    NSString *userSqlString  = @"select * from userInfoTable";
    FMResultSet *users_results = [self.qqDB.database executeQuery:userSqlString];
    while (users_results.next) {
        ZXMessageModel *userModel = [[ZXMessageModel alloc]init];
        [userModel doSetUserHeadImage:users_results];
        [self.users_Marray addObject:userModel ];
    }
    NSLog(@"%s [LINE:%d]meassages_Marray = %@ ,\n users_Marray=%@", __func__, __LINE__,self.meassages_Marray,self.users_Marray);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

@end
