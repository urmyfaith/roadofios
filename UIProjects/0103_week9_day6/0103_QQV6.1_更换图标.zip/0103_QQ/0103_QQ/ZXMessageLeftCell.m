//
//  ZXMessageLeftCell.m
//  0103_QQ
//
//  Created by zx on 1/3/15.
//  Copyright (c) 2015 zx. All rights reserved.
//

#import "ZXMessageLeftCell.h"
#import "ZXMessageModel.h"
#import "ZXUserModel.h"

@implementation ZXMessageLeftCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(ZXMessageLeftCell *)cellWithTableView:(UITableView *)tableView{
    static NSString *identifier = @"leftCell";
    
    ZXMessageLeftCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[ZXMessageLeftCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        

        
        
        UIImageView *leftImageView = [[UIImageView alloc]init];
        leftImageView.frame = CGRectMake(10, 5, 40, 40);
        [self.contentView addSubview:leftImageView];
        self.headImageView = leftImageView;
        
        
        UIImage *backImage = [UIImage imageNamed:@"left.png"];
        UIImageView *labelBackgroundImage = [[UIImageView alloc]init];
        labelBackgroundImage.frame = CGRectMake(CGRectGetMaxX(leftImageView.frame)+10, 5, 200, 30);
        labelBackgroundImage.image  = [backImage stretchableImageWithLeftCapWidth:40 topCapHeight:50];
        [self.contentView addSubview:labelBackgroundImage];
        self.contentImageView = labelBackgroundImage;
        
        
        UILabel *label4Content = [[UILabel alloc]init];
        label4Content.frame = CGRectMake(CGRectGetMaxX(leftImageView.frame)+10+20, 5, 170, 30);
        label4Content.font = [UIFont systemFontOfSize:17.0];
        [self.contentView addSubview:label4Content];
        label4Content.numberOfLines = 0;
        self.contentLabel  = label4Content;
        
    }
    return self;
}

-(void)setMessageModel:(ZXMessageModel *)messageModel{
    _messageModel = messageModel;
    self.contentLabel.text = messageModel.messageContent;
    
    self.contentLabel.frame = CGRectMake(CGRectGetMaxX(self.headImageView.frame)+10+30, 5, 170, 0);
    [self.contentLabel sizeToFit];
        
    UIImage *backImage = [UIImage imageNamed:@"balloon_left_purple.png"];

    CGSize size  = [self.contentLabel sizeThatFits:CGSizeMake(170,0)];
    if (size.height < 44) {
        if (size.width < 200) {
            self.contentImageView.frame = CGRectMake(CGRectGetMaxX(self.headImageView.frame)+10,0,size.width+10+30,44);
        }
        else
        {
            self.contentImageView.frame = CGRectMake(CGRectGetMaxX(self.headImageView.frame)+10,0,200+10,44);
        }
        self.contentLabel.center = CGPointMake(CGRectGetMaxX(self.headImageView.frame)+10+30 + size.width/2 ,44/2);
    }
    else
    {
        self.contentImageView.frame = CGRectMake(CGRectGetMaxX(self.headImageView.frame)+10,5,200+10,size.height+10);
    }
    
    self.contentImageView.image  = [backImage stretchableImageWithLeftCapWidth:16 topCapHeight:20];
}

-(void)setUserModel:(ZXUserModel *)userModel{
    _userModel = userModel;
    self.headImageView.image = [UIImage imageNamed:userModel.userHeadImage];
}

@end
