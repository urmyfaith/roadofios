//
//  ZXMessageRightCell.m
//  0103_QQ
//
//  Created by zx on 1/3/15.
//  Copyright (c) 2015 zx. All rights reserved.
//

#import "ZXMessageRightCell.h"
#import "ZXMessageModel.h"
#import "ZXUserModel.h"

@implementation ZXMessageRightCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
+(ZXMessageRightCell *)cellWithTableView:(UITableView *)tableView{
    static NSString *identifier = @"leftCell";
    
    ZXMessageRightCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[ZXMessageRightCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
                
        UIImageView *rightImageView = [[UIImageView alloc]init];
        rightImageView.frame = CGRectMake(320-50, 5, 40, 40);
        [self.contentView addSubview:rightImageView];
        self.headImageView = rightImageView;
        
        
        UIImage *backImage = [UIImage imageNamed:@"left"];
        UIImageView *contentBackground = [[UIImageView alloc]init];
        contentBackground.frame = CGRectMake(50, 5, 200, 30);
        contentBackground.image  = [backImage stretchableImageWithLeftCapWidth:70 topCapHeight:40];
        [self.contentView addSubview:contentBackground];
        
        UILabel *label4Content = [[UILabel alloc]init];
        label4Content.font = [UIFont systemFontOfSize:17.0];
        label4Content.numberOfLines = 0;
        label4Content.frame = CGRectMake(50, 10, 200, 30);
        [self.contentView addSubview:label4Content];
        self.contentLabel  = label4Content;
        
    }
    return self;
}

-(void)setMessageModel:(ZXMessageModel *)messageModel{
    _messageModel = messageModel;
    self.contentLabel.text = messageModel.messageContent;
    
    CGSize size  = [self.contentLabel sizeThatFits:CGSizeMake(200,0)];
    self.contentLabel.frame = CGRectMake(320-40-10*2-size.width, 5, 200, 0);
    [self.contentLabel sizeToFit];
}

-(void)setUserModel:(ZXUserModel *)userModel{
    _userModel = userModel;
    self.headImageView.image = [UIImage imageNamed:userModel.userHeadImage];
}


@end
