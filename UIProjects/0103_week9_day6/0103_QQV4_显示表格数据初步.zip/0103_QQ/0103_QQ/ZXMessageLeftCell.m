//
//  ZXMessageLeftCell.m
//  0103_QQ
//
//  Created by zx on 1/3/15.
//  Copyright (c) 2015 zx. All rights reserved.
//

#import "ZXMessageLeftCell.h"
#import "ZXMessageModel.h"
#import "ZXUserModel.h"

@implementation ZXMessageLeftCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(ZXMessageLeftCell *)cellWithTableView:(UITableView *)tableView{
    static NSString *identifier = @"leftCell";
    
    ZXMessageLeftCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[ZXMessageLeftCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        UIView *backgroundView = [[UIView alloc] init];
        backgroundView.frame = CGRectMake(0, 0, 320, 44);
        backgroundView.backgroundColor = [UIColor colorWithRed:228./255. green:227./255. blue:232./255 alpha:0.5];
        [self.contentView addSubview:backgroundView];
        
        
        UIImageView *leftImageView = [[UIImageView alloc]init];
        leftImageView.frame = CGRectMake(10, 5, 40, 40);
        [self.contentView addSubview:leftImageView];
        self.headImageView = leftImageView;
        
        
        UIImage *backImage = [UIImage imageNamed:@"right.png"];
        UIImageView *labelBackgroundImage = [[UIImageView alloc]init];
        labelBackgroundImage.frame = CGRectMake(CGRectGetMaxX(leftImageView.frame)+10, 5, 200, 30);
        labelBackgroundImage.image  = [backImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
        [self.contentView addSubview:labelBackgroundImage];
        
        UILabel *label4Content = [[UILabel alloc]init];
        label4Content.frame = CGRectMake(CGRectGetMaxX(leftImageView.frame)+10, 5, 200, 30);
        [self.contentView addSubview:label4Content];
        self.contentLabel  = label4Content;
        
    }
    return self;
}

-(void)setMessageModel:(ZXMessageModel *)messageModel{
    _messageModel = messageModel;
    self.contentLabel.text = messageModel.messageContent;
}

-(void)setUserModel:(ZXUserModel *)userModel{
    _userModel = userModel;
    self.headImageView.image = [UIImage imageNamed:userModel.userHeadImage];
}

@end
