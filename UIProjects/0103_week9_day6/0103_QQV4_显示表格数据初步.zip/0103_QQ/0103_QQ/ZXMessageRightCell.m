//
//  ZXMessageRightCell.m
//  0103_QQ
//
//  Created by zx on 1/3/15.
//  Copyright (c) 2015 zx. All rights reserved.
//

#import "ZXMessageRightCell.h"
#import "ZXMessageModel.h"
#import "ZXUserModel.h"

@implementation ZXMessageRightCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
+(ZXMessageRightCell *)cellWithTableView:(UITableView *)tableView{
    static NSString *identifier = @"leftCell";
    
    ZXMessageRightCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[ZXMessageRightCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        UIView *backgroundView = [[UIView alloc] init];
        backgroundView.frame = CGRectMake(0, 0, 320, 44);
        backgroundView.backgroundColor = [UIColor colorWithRed:228./255. green:227./255. blue:232./255 alpha:0.5];
        [self.contentView addSubview:backgroundView];
        
        
        UIImageView *rightImageView = [[UIImageView alloc]init];
        rightImageView.frame = CGRectMake(320-50, 5, 40, 40);
        [self.contentView addSubview:rightImageView];
        self.headImageView = rightImageView;
        
        
        UIImage *backImage = [UIImage imageNamed:@"left"];
        UIImageView *contentBackground = [[UIImageView alloc]init];
        contentBackground.frame = CGRectMake(50, 5, 200, 30);
        contentBackground.image  = [backImage stretchableImageWithLeftCapWidth:70 topCapHeight:40];
        [self.contentView addSubview:contentBackground];
        
        UILabel *label4Content = [[UILabel alloc]init];
        label4Content.frame = CGRectMake(50, 5, 200, 30);
        [self.contentView addSubview:label4Content];
        self.contentLabel  = label4Content;
        
    }
    return self;
}

-(void)setMessageModel:(ZXMessageModel *)messageModel{
    _messageModel = messageModel;
    self.contentLabel.text = messageModel.messageContent;
}

-(void)setUserModel:(ZXUserModel *)userModel{
    _userModel = userModel;
    self.headImageView.image = [UIImage imageNamed:userModel.userHeadImage];
}


@end
