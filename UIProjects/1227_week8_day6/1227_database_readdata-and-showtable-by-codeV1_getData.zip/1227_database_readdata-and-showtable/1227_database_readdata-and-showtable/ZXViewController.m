//
//  ZXViewController.m
//  1227_database_readdata-and-showtable
//
//  Created by zx on 12/27/14.
//  Copyright (c) 2014 zuoxue@qq.com. All rights reserved.
//

#import "ZXViewController.h"
#import "ZXDatabase.h"
#import "ZXFirstLevelDataModel.h"

@interface ZXViewController ()

@end

@implementation ZXViewController
/**
 *  
 题目：将提供的数据库里面的first level表中的数据取出来，展示到tableView中
 要求：
 
 1.将取数据的过程通过单例实现
 2.要建立数据模型
 3.自定义cell（两种：纯代码，xib）
 */
- (void)viewDidLoad
{
    [super viewDidLoad];
	ZXDatabase *zxSharedDB = [ZXDatabase shardInstance];
    NSLog(@"%s [LINE:%d]%@", __func__, __LINE__,[zxSharedDB firstLevelTable_Marray]);
}


@end
