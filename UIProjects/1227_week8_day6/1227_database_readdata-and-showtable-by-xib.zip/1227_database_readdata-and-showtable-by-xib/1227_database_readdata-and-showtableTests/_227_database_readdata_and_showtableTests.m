//
//  _227_database_readdata_and_showtableTests.m
//  1227_database_readdata-and-showtableTests
//
//  Created by zx on 12/27/14.
//  Copyright (c) 2014 zuoxue@qq.com. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _227_database_readdata_and_showtableTests : XCTestCase

@end

@implementation _227_database_readdata_and_showtableTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
