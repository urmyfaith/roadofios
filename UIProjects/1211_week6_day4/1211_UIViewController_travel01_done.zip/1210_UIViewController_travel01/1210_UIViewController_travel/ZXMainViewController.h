//
//  ZXMainViewController.h
//  1210_UIViewController_travel
//
//  Created by zx on 12/10/14.
//  Copyright (c) 2014 zx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXMainViewController : UIViewController

@property(nonatomic,copy)NSString *name;

@property(nonatomic,strong)NSArray *imageNameArray;
@property(nonatomic,strong)NSArray *imageDescriptionArray;

@end
