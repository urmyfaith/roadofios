//
//  ZXBlock.h
//  1209_UIView01
//
//  Created by zx on 12/9/14.
//  Copyright (c) 2014 zx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXBlock : UIView

@property (nonatomic,assign)CGFloat xSpeed;//x轴方向的速度.
@property (nonatomic,assign)CGFloat ySpeed;
@end
