//
//  main.m
//  01-UINavigationController的创建
//
//  Created by zx on 14-12-15.
//  Copyright (c) 2014年 zx. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZXAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZXAppDelegate class]));
    }
}
