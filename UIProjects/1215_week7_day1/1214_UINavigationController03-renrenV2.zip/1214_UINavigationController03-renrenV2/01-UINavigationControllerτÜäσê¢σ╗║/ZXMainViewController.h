//
//  ZKFirstViewController.h
//  01-UINavegationControllerDemo创建
//
//  Created by zx on 14-12-15.
//  Copyright (c) 2014年 zx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXMainViewController : UIViewController

@property (nonatomic,copy) NSMutableArray *navigationMArray;
@property (nonatomic,strong)UIView *centerView;

@end
