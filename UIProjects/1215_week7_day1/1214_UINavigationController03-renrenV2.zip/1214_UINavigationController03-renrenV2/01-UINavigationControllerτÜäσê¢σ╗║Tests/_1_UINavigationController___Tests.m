//
//  _1_UINavigationController___Tests.m
//  01-UINavigationController的创建Tests
//
//  Created by zx on 14-12-15.
//  Copyright (c) 2014年 zx. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _1_UINavigationController___Tests : XCTestCase

@end

@implementation _1_UINavigationController___Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
