//
//  _224_custom_cell_by_xibTests.m
//  1224_custom-cell-by-xibTests
//
//  Created by zx on 12/24/14.
//  Copyright (c) 2014 zuoxue@qq.com. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _224_custom_cell_by_xibTests : XCTestCase

@end

@implementation _224_custom_cell_by_xibTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
