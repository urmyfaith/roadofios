//
//  ZXTweetCell.m
//  1231_simple_weibo
//
//  Created by zx on 12/31/14.
//  Copyright (c) 2014 zx. All rights reserved.
//

#import "ZXTweetCell.h"
#import "ZXTweetModel.h"
#import "UIImageView+WebCache.h"

@implementation ZXTweetCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self =  [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        CGFloat gap = 10;
        UIImageView *tempIcon = [[UIImageView alloc]initWithFrame:CGRectMake(gap, gap, 50, 50)];
        [self.contentView addSubview:tempIcon];
        self.iconView = tempIcon;
        
        UILabel *tempTitle = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(tempIcon.frame)+gap, gap, 200, 30)];
        tempTitle.font = [UIFont systemFontOfSize:17];
        [self.contentView addSubview:tempTitle];
        self.titleLabel = tempTitle;
        
        
        UILabel *tempContent = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(tempIcon.frame)+gap,
                                                                        CGRectGetMaxY(tempTitle.frame) +gap,
                                                                        200,
                                                                        40)];
        tempContent.font = [UIFont systemFontOfSize:12];
        tempContent.numberOfLines = 0;
        [self.contentView addSubview:tempContent];
        self.contentLabel = tempContent;
        
        
        UIImageView *tempSmall = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(tempIcon.frame)+gap,
                                                                              CGRectGetMaxY(tempContent.frame) +gap,
                                                                              50,
                                                                              50)];
        [self.contentView addSubview:tempSmall];
        self.smallView = tempSmall;
        
        UILabel *tempDate = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(tempIcon.frame)+gap,
                                                                     CGRectGetMaxY(tempSmall.frame) +gap,
                                                                     200,
                                                                     30 )];
        tempDate.font = [UIFont systemFontOfSize:10];
        [self.contentView addSubview:tempDate];
        self.nowDateLabel = tempDate ;
        
        UIImage *image = [UIImage imageNamed:@"comment.png"];
        UIImageView *tempCommentView = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(tempTitle.frame)+gap,
                                                                                    gap,
                                                                                    image.size.width,
                                                                                    image.size.height)];
        tempCommentView.image = image;
        [self.contentView addSubview:tempCommentView];
        
        UILabel *tempComment = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(tempCommentView.frame),
                                                                        gap,
                                                                        20,
                                                                        20)];
        [self.contentView addSubview:tempComment];
        self.commentLabel = tempComment;
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

-(void)setMyModel:(ZXTweetModel *)myModel{
    _myModel = myModel;
    self.titleLabel.text = myModel.author;
    self.contentLabel.text = myModel.body;
    self.nowDateLabel.text = myModel.pubDate;
    self.commentLabel.text = myModel.commentCount;
    
    int smallHeight = 0;
    [self.iconView setImageWithURL:[NSURL URLWithString:myModel.portrait]];
    if ([myModel.imgSmall isEqualToString:@"" ]) {
       
        smallHeight = 0;
    }
    else{
        [self.smallView setImageWithURL:[NSURL URLWithString:myModel.imgSmall]];
        smallHeight = 50;
    }
}
-(void)setModel:(ZXTweetModel *)myModel andShow:(BOOL)isShouldShow{
//    _myModel = myModel;
    self.smallView.hidden = NO;
    
    self.titleLabel.text = myModel.author;
    self.contentLabel.text = myModel.body;
    self.nowDateLabel.text = myModel.pubDate;
    self.commentLabel.text = myModel.commentCount;

    self.contentLabel.frame = CGRectMake(CGRectGetMaxX(self.iconView.frame)+ 10,CGRectGetMaxY(self.titleLabel.frame)+10,200,0);
    [self.contentLabel sizeToFit];
  
    //得到自适应后的大小
    CGSize size  = [self.contentLabel sizeThatFits:CGSizeMake(200,0)];
    
    [self.iconView setImageWithURL:[NSURL URLWithString:myModel.portrait]];
    if (isShouldShow == YES) {
        [self.smallView setImageWithURL:[NSURL URLWithString:myModel.imgSmall]];
        self.smallView.frame = CGRectMake(CGRectGetMaxX(self.iconView.frame)+ 10,CGRectGetMaxY(self.contentLabel.frame)+10,50,50);
        self.nowDateLabel.frame = CGRectMake(CGRectGetMaxX(self.iconView.frame)+ 10,CGRectGetMaxY(self.smallView.frame)+10,200,30);
    }
    else{
        self.smallView.hidden = YES;
        self.nowDateLabel.frame = CGRectMake(CGRectGetMaxX(self.iconView.frame)+ 10,CGRectGetMaxY(self.contentLabel.frame)+10,200,30);
    }
}

+(ZXTweetCell *)cellWithTableView:(UITableView *)tableView{
    static NSString *identifier = @"cell";
    ZXTweetCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[ZXTweetCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    return cell;
}
@end
