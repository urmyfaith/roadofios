//
//  ZXModifyOrAddViewController.h
//  1223_exercisev1
//
//  Created by zx on 12/23/14.
//  Copyright (c) 2014 zuoxue@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXModifyOrAddViewController : UIViewController

@property(nonatomic,strong)UITextField *nameTextFiled;
@property(nonatomic,strong)UITextField *sexTextFiled;
@property(nonatomic,strong)UITextField *telephoneTextFiled;
@property(nonatomic,strong)UITextField *IDTextFiled;

@property(nonatomic,strong)NSString *sting4RowNumber;

@end
